<?php
    return [
        'paths' => ["*"],
        'allowed_methods' => ["*"],
        'allow_origins' => ["*"],
        'allow_headers' => ["*"],
        'allow_credentials' => false,
        'expose_headers' => ["*"],
        'max_age' => 0
    ]
?>

